<?php $__env->startSection('title', __('Not Found')); ?>
<?php $__env->startSection('code'); ?>
    <h3>Sorry, that page doesn't exist.</h3>
    <a style="color:blue" href="/">Return back</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('message'); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/latest/resources/views/errors/404.blade.php ENDPATH**/ ?>