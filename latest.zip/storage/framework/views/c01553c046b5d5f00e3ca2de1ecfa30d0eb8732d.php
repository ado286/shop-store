<?php if($paginator->hasPages()): ?>
    <div class="flex items-center">
        
        <?php if($paginator->onFirstPage()): ?>
            <span class="rounded-l rounded-sm border border-brand-light px-3 py-2 cursor-not-allowed no-underline">&laquo;</span>
        <?php else: ?>
            <a
                class="rounded-l rounded-sm border-t border-b border-l border-brand-light px-3 py-2 text-brand-dark hover:bg-brand-light no-underline"
                href="<?php echo e($paginator->previousPageUrl()); ?>"
                rel="prev"
            >
                &laquo;
            </a>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <span class="border-t border-b border-l border-brand-light px-3 py-2 cursor-not-allowed no-underline"><?php echo e($element); ?></span>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="border-t border-b border-l border-brand-light px-3 py-2 bg-brand-light no-underline"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a class="border-t border-b border-l border-brand-light px-3 py-2 hover:bg-brand-light text-brand-dark no-underline" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <a class="rounded-r rounded-sm border border-brand-light px-3 py-2 hover:bg-brand-light text-brand-dark no-underline" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">&raquo;</a>
        <?php else: ?>
            <span class="rounded-r rounded-sm border border-brand-light px-3 py-2 hover:bg-brand-light text-brand-dark no-underline cursor-not-allowed">&raquo;</span>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH /opt/lampp/htdocs/latest/resources/views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>