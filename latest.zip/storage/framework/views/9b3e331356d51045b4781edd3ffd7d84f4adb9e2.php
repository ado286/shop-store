<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1>Delete product</h1>

        <table class="table table-hover">
        <thead>
          <tr>
            <th>Name of Product</th>
            <th>Price</th>
            <th>Image</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td><img width="100px" src="<?php echo e($product->photo ? $product->photo->file : "http://via.placeholder.com/100x100"); ?>" alt=""></td>
            <td>
                <form action="<?php echo e(route('product.destroy', ['product'=>$product->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="submit" class="btn btn-danger">
                        Delete
                    </button>
                </form>
                <br>
                <form action="<?php echo e(route('product.edit',['product'=>$product->id])); ?>" method="POST">
                    <?php echo method_field('GET'); ?>
                    <button type="submit" class="">
                        Edit
                    </button>
                </form>
                <hr>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/latest/resources/views/product/index.blade.php ENDPATH**/ ?>